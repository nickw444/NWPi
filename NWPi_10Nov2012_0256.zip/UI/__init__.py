#####################################################################
### Copyright Nick Whyte 2012
### All Rights Reserved (c)
### Distribution, Modification and Attribution Strictly Prohibited
### Legal Action may be taken
### http://www.nickwhyte.com/
#####################################################################

# import NWPi
from homeViewController import *
from secondAlternativeView import *
from firstAlternativeView import *

# ! Definitions for separate view controllers
# Here we will define each view controller for later initialisation and use
# lets put a copyable template here:
# class controllerName(viewController):
    # def customInitial(self):
